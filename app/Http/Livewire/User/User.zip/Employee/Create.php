<?php

namespace App\Http\Livewire\User\Employee;

use Livewire\Component;

class Create extends Component
{
    public function render()
    {
        return view('livewire.user.employee.create');
    }
}
