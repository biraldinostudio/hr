<?php

namespace App\Http\Livewire\User\Employee;

use Livewire\Component;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\DB;
class UpdateAll extends Component
{
    public $countEmployees;
    protected $listeners=[
        'resetPasswordEmployee'=>'showModal'
    ];


    public function mount(){
        $this->initializedProperties();
    }
    public function render()
    {
        return view('livewire.user.employee.update-all');
    }

    public function showModal(){
        $this->countEmployees=User::where('active')->where('level','employee')->where('employee','1')->count();
        $this->employees=User::where('active')->where('level','employee')->where('employee','1')->get();
        $this->emit('showModal','editModal');
    }

    public function resetPasswordAll(){
        $this->dateBirth=date('d/m/Y',strtotime($employees->date_of_birth));
        $birtdateConvert= str_replace('/', '-', $this->dateBirth);
        DB::beginTransaction();
        try{
            $employees = User::whereId($this->employeeId)->first();
            $employees->password=Hash::make(trim($this->nrp).date('dmy', strtotime($birtdateConvert)));
            $employees->save();


            ItemTable::where('item_type_id', '=', 1)
            ->update(['colour' => 'black']);



            $this->emit('flashMessage',[
                'type'=>'success',
                'title'=>'Reset Password',
                'message'=>'Berhasil reset password!'
            ]);
            $this->initializedProperties();
            $this->emit('closeModal','editModal');
            $this->emit('reloadUserEmployees');
            $this->initializedProperties();
           
        }catch(\Throwable $th){
            DB::rollBack();
            $this->emit('flashMessage',[
                'type'=>'error',
                'title'=>'Reset Password',
                'message'=>'Error:'.$th->getMessage()
            ]);
        }
        DB::commit();
    }   

    private function initializedProperties(){
        $this->countEmployees=null;
    }

    public function cancel(){
        $this->resetErrorBag();
        $this->initializedProperties();
    }
}
