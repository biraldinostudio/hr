<?php

namespace App\Http\Livewire\User\MyAccount;

use Livewire\Component;

class Delete extends Component
{
    public function render()
    {
        return view('livewire.user.my-account.delete');
    }
}
