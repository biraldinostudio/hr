<?php

namespace App\Http\Livewire\User\MyAccount;

use Livewire\Component;

class Update extends Component
{

}
