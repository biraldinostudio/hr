<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Model;
 
class ViewCountTransDept extends Model
{
    
    public $table = "view_count_trans_depts";
}