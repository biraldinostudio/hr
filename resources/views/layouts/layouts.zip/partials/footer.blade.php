  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Developer &copy; 2021 <a href="https://youtube.com/BiraldinoStudio">{{config('app.developer')}}</a>
    </div>
    <!-- Default to the left -->
    <strong>{{config('app.company')}} .</strong> All rights reserved.
  </footer>