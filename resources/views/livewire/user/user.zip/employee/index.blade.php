<div>
    <livewire:user.employee.show/>
	<livewire:user.employee.update/>
</div>