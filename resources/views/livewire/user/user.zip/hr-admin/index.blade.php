<div>
    <livewire:user.hr-admin.show/>
	<livewire:user.hr-admin.create/>
    <livewire:user.hr-admin.delete/>
</div>
