<div>
    <livewire:user.hr-head.show/>
	<livewire:user.hr-head.create/>
    <livewire:user.hr-head.delete/>
</div>
