<div>
    <livewire:user.administrator.show/>
	<livewire:user.administrator.create/>
    <livewire:user.administrator.delete/>
</div>