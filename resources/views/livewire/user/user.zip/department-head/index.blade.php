<div>
    <livewire:user.department-head.show/>
	<livewire:user.department-head.create/>
    <livewire:user.department-head.delete/>
</div>