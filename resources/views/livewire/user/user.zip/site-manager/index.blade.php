<div>
    <livewire:user.site-manager.show/>
	<livewire:user.site-manager.create/>
    <livewire:user.site-manager.delete/>
</div>