<div>
    <livewire:user.my-account.show/>
	<livewire:user.my-account.create/>
	<livewire:user.my-account.update/>
    <livewire:user.my-account.delete/>
</div>